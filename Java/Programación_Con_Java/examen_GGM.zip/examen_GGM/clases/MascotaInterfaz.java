/**
 * Explica tu código aquí
 * 
 * @author Giovanni Giove
*/
package clases;

public interface MascotaInterfaz {

  /////Métodos
  public static void name(String pasear) {
    
  }

  

  

}
